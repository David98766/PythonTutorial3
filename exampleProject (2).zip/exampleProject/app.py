# app.py
from flask import Flask, render_template, session, redirect, url_for, flash
from service.CourseService import CourseService

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Replace with a strong secret key in production

course_service = CourseService()


@app.before_request
def initialize_cart():
    if 'cart' not in session:
        session['cart'] = []


@app.route('/')
def show_courses():
    courses = course_service.get_all_courses()
    return render_template('course_list.html', courses=courses)


@app.route('/course/<int:course_id>')
def show_course(course_id):
    course = course_service.get_course_details(course_id)
    if course:
        return render_template('course_detail.html', course=course)
    else:
        return "Course not found", 404


@app.route('/add_to_cart/<int:course_id>', methods=['POST'])
def add_to_cart(course_id):
    course = course_service.get_course_details(course_id)
    if not course:
        flash('Course not found.', 'error')
        return redirect(url_for('show_courses'))

    cart = session.get('cart', [])
    if course_id in cart:
        flash('Course is already in your cart.', 'info')
    else:
        cart.append(course_id)
        session['cart'] = cart
        flash('Course added to your cart.', 'success')

    return redirect(url_for('show_course', course_id=course_id))


@app.route('/cart')
def view_cart():
    cart = session.get('cart', [])
    courses = [course_service.get_course_details(course_id) for course_id in cart]
    # Remove any None values in case a course was deleted
    courses = [course for course in courses if course is not None]
    return render_template('cart.html', courses=courses)


@app.route('/remove_from_cart/<int:course_id>', methods=['POST'])
def remove_from_cart(course_id):
    cart = session.get('cart', [])
    if course_id in cart:
        cart.remove(course_id)
        session['cart'] = cart
        flash('Course removed from your cart.', 'success')
    else:
        flash('Course not found in your cart.', 'error')
    return redirect(url_for('view_cart'))


if __name__ == '__main__':
    app.run(debug=True)
