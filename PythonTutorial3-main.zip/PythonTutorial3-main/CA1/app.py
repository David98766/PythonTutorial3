# app.py

from flask import Flask, render_template, url_for, redirect, flash
from service.ProductService import ProductService

app = Flask(__name__)
app.secret_key = "your_secret_key"  # Required for flash messages
product_service = ProductService()

@app.route('/')
def home():
    return redirect(url_for('show_products'))

@app.route('/products')
def show_products():
    products = product_service.get_all_products()
    return render_template('ProductSpread.html', products=products)

@app.route('/product/<int:product_id>')
def show_product(product_id):
    product = product_service.get_product_details(product_id)
    if product:
        return render_template('IndividualProduct.html', product=product)
    else:
        flash("Product not found.")
        return redirect(url_for('show_products'))

if __name__ == '__main__':
    app.run(debug=True)
