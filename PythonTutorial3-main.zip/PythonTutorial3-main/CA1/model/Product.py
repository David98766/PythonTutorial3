# model/Product.py

class Product:
    def __init__(self, product_id, name, description, price, category, image_name):
        self.product_id = product_id
        self.name = name
        self.description = description
        self.price = price
        self.category = category
        self.image_name = image_name
