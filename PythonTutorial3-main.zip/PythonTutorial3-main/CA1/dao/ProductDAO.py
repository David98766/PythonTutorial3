# dao/ProductDAO.py

from model.Product import Product

class ProductDAO:
    def __init__(self):
        self.products = [
            Product(1, "Daffodil Bulbs", "Vibrant yellow daffodils to brighten your garden.", 5, "Summer Radiance", "Daffodil.jpg"),
            Product(2, "Rose Seeds", "Radiant roses to add a touch of romance to your space.", 5, "Flower seeds", "Rose.jpg"),
            Product(3, "Marigold Seeds", "Blooming marigolds to add a splash of vibrant color and charm.", 5, "Springtime Charm", "Marigold.jpeg"),
            Product(4, "Tulip Bulbs", "Elegant tulips to infuse elegance into your garden.", 5, "Colorful Annuals", "Tulip.jpeg"),
            Product(5, "Lavender Seeds", "Fragrant lavender fields to soothe your senses.", 5, "Romantic Blooms", "Lavender.jpg"),
            Product(6, "Zinnia Seeds", "Zesty zinnia to spice up your garden.", 5, "Aromatic Herbs", "Zinnia.jpg"),
            Product(7, "Poppy Seeds", "Powerful poppies to add some pop to your garden.", 5, "Wildflower Wonders", "Poppy.jpg"),
            Product(8, "Daffodil Bulbs", "Delightful daffodils to defy the darkness.", 5, "Sunshine Annuals", "Daffodil.jpg"),
        ]

    def get_all_products(self):
        return self.products

    def get_product_by_id(self, product_id):
        for product in self.products:
            if product.product_id == product_id:
                return product
        return None
