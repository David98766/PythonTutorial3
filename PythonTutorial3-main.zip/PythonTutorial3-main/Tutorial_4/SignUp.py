from userservice.UserService import UserService
from validation.UserValidation import UserValidation

userValidation = UserValidation

userService = UserService(userValidation)

userService.signUp()