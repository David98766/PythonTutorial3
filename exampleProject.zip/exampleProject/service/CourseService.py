from dao.CourseDAO import CourseDAO

class CourseService:
    def __init__(self):
        self.course_dao = CourseDAO()

    def get_all_courses(self):
        return self.course_dao.get_all_courses()

    def get_course_details(self, course_id):
        return self.course_dao.get_course_by_id(course_id)
