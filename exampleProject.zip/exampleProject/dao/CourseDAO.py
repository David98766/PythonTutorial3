from model.Course import Course

class CourseDAO:
    def __init__(self):
        self.courses = [
            Course(1, "Introduction to Python", "Learn the basics of Python programming.", "John Doe"),
            Course(2, "Advanced Java", "Master advanced concepts in Java programming.", "Jane Smith"),
            Course(3, "Web Development with JavaScript", "Build dynamic websites using JavaScript.", "Emily Johnson"),
            Course(4, "Data Science with R", "Explore data analysis and visualization with R.", "Michael Brown"),
            Course(5, "Machine Learning Fundamentals", "An introduction to machine learning algorithms.", "Sarah Davis"),
            Course(6, "Cloud Computing with AWS", "Learn about cloud services using AWS.", "David Wilson"),
            Course(7, "Cybersecurity Basics", "Understand the fundamentals of cybersecurity.", "Laura Martinez"),
            Course(8, "Blockchain Essentials", "Explore blockchain technology and its applications.", "Robert Anderson"),
        ]

    def get_all_courses(self):
        return self.courses

    def get_course_by_id(self, course_id):
        for course in self.courses:
            if course.course_id == course_id:
                return course
        return None
