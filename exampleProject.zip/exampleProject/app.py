from flask import Flask, render_template
from service.CourseService import CourseService

app = Flask(__name__)

course_service = CourseService()

@app.route('/')
def show_courses():
    courses = course_service.get_all_courses()
    return render_template('course_list.html', courses=courses)

@app.route('/course/<int:course_id>')
def show_course(course_id):
    course = course_service.get_course_details(course_id)
    if course:
        return render_template('course_detail.html', course=course)
    else:
        return "Course not found", 404

if __name__ == '__main__':
    app.run(debug=True)
